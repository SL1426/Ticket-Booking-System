<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['payment_success']) || !isset($_SESSION['booking_id'])) {
    header("Location: index.php");
    exit();
}

// Fetch booking details
$stmt = $pdo->prepare("
    SELECT b.*, m.title, m.poster_url, s.show_date, s.show_time, t.name as theater_name
    FROM bookings b
    JOIN shows s ON b.show_id = s.show_id
    JOIN movies m ON s.movie_id = m.movie_id
    JOIN theaters t ON s.theater_id = t.theater_id
    WHERE b.booking_id = ? AND b.user_id = ?
");
$stmt->execute([$_SESSION['booking_id'], $_SESSION['user_id']]);
$booking = $stmt->fetch();

// Clear session variables
unset($_SESSION['payment_success']);
unset($_SESSION['booking_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmation - Movie Ticket Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #f84464;
            --secondary-color: #1f2533;
        }

        body {
            background-color: #f5f5f5;
        }

        .confirmation-container {
            max-width: 600px;
            margin: 0 auto;
        }

        .confirmation-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 20px;
        }

        .success-icon {
            font-size: 48px;
            color: #28a745;
        }

        .movie-poster {
            width: 120px;
            border-radius: 5px;
        }

        .booking-details {
            background-color: var(--secondary-color);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }

        .booking-id {
            font-family: monospace;
            font-size: 1.2rem;
            color: var(--primary-color);
            background: rgba(248, 68, 100, 0.1);
            padding: 5px 10px;
            border-radius: 5px;
        }

        .back-btn {
            background-color: var(--primary-color);
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .back-btn:hover {
            background-color: #e03a58;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container mt-5 mb-5">
        <div class="confirmation-container">
            <div class="confirmation-card text-center">
                <i class="fas fa-check-circle success-icon mb-3"></i>
                <h2>Booking Confirmed!</h2>
                <p class="text-muted">Your movie tickets have been booked successfully.</p>
                
                <div class="booking-details">
                    <div class="row align-items-center">
                        <div class="col-md-4">
                            <img src="<?php echo htmlspecialchars($booking['poster_url']); ?>" class="movie-poster" alt="Movie Poster">
                        </div>
                        <div class="col-md-8 text-start">
                            <h4><?php echo htmlspecialchars($booking['title']); ?></h4>
                            <p class="mb-1">
                                <i class="fas fa-theater-masks me-2"></i>
                                <?php echo htmlspecialchars($booking['theater_name']); ?>
                            </p>
                            <p class="mb-1">
                                <i class="far fa-calendar me-2"></i>
                                <?php echo date('d M Y', strtotime($booking['show_date'])); ?>
                            </p>
                            <p class="mb-0">
                                <i class="far fa-clock me-2"></i>
                                <?php echo date('h:i A', strtotime($booking['show_time'])); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="text-start mb-4">
                    <p class="mb-2">Booking ID: <span class="booking-id"><?php echo $booking['booking_id']; ?></span></p>
                    <p class="mb-2">Number of Seats: <?php echo $booking['total_seats']; ?></p>
                    <p class="mb-2">Total Amount:  ₹<?php echo number_format($booking['total_amount'], 2); ?></p>
                    <p class="mb-0">Booking Date: <?php echo date('d M Y, h:i A', strtotime($booking['booking_date'])); ?></p>
                </div>

                <div class="text-center">
                    <a href="bookings.php" class="back-btn">View My Bookings</a>
                </div>
            </div>

            <div class="mt-3 text-center">
                <p class="text-muted mb-0">A confirmation email has been sent to your registered email address.</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 