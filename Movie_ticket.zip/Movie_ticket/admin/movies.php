<?php
require_once '../config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $release_date = $_POST['release_date'];
    $duration = (int)$_POST['duration'];
    $trailer_url = trim($_POST['trailer_url']);
    $status = $_POST['status'];

    // Handle file upload
    $poster_url = '';
    if (isset($_FILES['poster_image']) && $_FILES['poster_image']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['poster_image']['tmp_name'];
        $file_name = $_FILES['poster_image']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Generate unique filename
        $unique_filename = uniqid() . '.' . $file_ext;
        $upload_path = '../uploads/' . $unique_filename;
        
        // Check if file is an image
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($file_ext, $allowed_types)) {
            $errors[] = "Only JPG, JPEG, PNG & GIF files are allowed.";
        } else {
            if (move_uploaded_file($file_tmp, $upload_path)) {
                $poster_url = 'uploads/' . $unique_filename;
            } else {
                $errors[] = "Failed to upload image.";
            }
        }
    } else {
        $errors[] = "Poster image is required";
    }

    if (empty($title)) $errors[] = "Title is required";
    if (empty($description)) $errors[] = "Description is required";
    if (empty($release_date)) $errors[] = "Release date is required";
    if ($duration <= 0) $errors[] = "Duration must be positive";
    if (empty($trailer_url)) $errors[] = "Trailer URL is required";

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO movies (title, description, release_date, duration, trailer_url, poster_url, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$title, $description, $release_date, $duration, $trailer_url, $poster_url, $status]);
            $success = true;
        } catch(PDOException $e) {
            $errors[] = "Failed to add movie: " . $e->getMessage();
        }
    }
}

// Fetch all movies
$stmt = $pdo->query("SELECT * FROM movies ORDER BY release_date DESC");
$movies = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Movies - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Manage Movies</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                Movie added successfully!
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Add New Movie</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <input type="text" class="form-control" id="title" name="title" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="release_date" class="form-label">Release Date</label>
                                <input type="date" class="form-control" id="release_date" name="release_date" required>
                            </div>
                            <div class="mb-3">
                                <label for="duration" class="form-label">Duration (minutes)</label>
                                <input type="number" class="form-control" id="duration" name="duration" required>
                            </div>
                            <div class="mb-3">
                                <label for="trailer_url" class="form-label">Trailer URL</label>
                                <input type="url" class="form-control" id="trailer_url" name="trailer_url" required>
                            </div>
                            <div class="mb-3">
                                <label for="poster_image" class="form-label">Poster Image</label>
                                <input type="file" class="form-control" id="poster_image" name="poster_image" accept="image/*" required>
                                <small class="text-muted">Accepted formats: JPG, JPEG, PNG, GIF</small>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="upcoming">Upcoming</option>
                                    <option value="now_showing">Now Showing</option>
                                    <option value="ended">Ended</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Movie</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5>Movie List</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Poster</th>
                                        <th>Release Date</th>
                                        <th>Duration</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($movies as $movie): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($movie['title']); ?></td>
                                            <td>
                                                <img src="<?php echo '../' . $movie['poster_url']; ?>" alt="<?php echo htmlspecialchars($movie['title']); ?>" style="max-width: 50px;">
                                            </td>
                                            <td><?php echo date('Y-m-d', strtotime($movie['release_date'])); ?></td>
                                            <td><?php echo $movie['duration']; ?> minutes</td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $movie['status'] == 'now_showing' ? 'success' : 
                                                        ($movie['status'] == 'upcoming' ? 'warning' : 'secondary');
                                                ?>">
                                                    <?php echo ucfirst($movie['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="edit_movie.php?id=<?php echo $movie['movie_id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                                <a href="delete_movie.php?id=<?php echo $movie['movie_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 