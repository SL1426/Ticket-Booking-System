<?php
require_once '../config.php';

// Generate a new password hash
$password = 'admin123';
$hash = password_hash($password, PASSWORD_BCRYPT);

try {
    // Update admin password
    $stmt = $pdo->prepare("UPDATE admin SET password = ? WHERE username = 'admin'");
    $stmt->execute([$hash]);
    
    echo "Admin password has been reset successfully!<br>";
    echo "Username: admin<br>";
    echo "Password: admin123<br>";
    echo "New hash: " . $hash;
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 