<?php
require_once '../config.php';

// Test password hash
$password = 'admin123';
$hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

echo "Testing password verification:\n";
echo "Password: " . $password . "\n";
echo "Hash: " . $hash . "\n";
echo "Verification result: " . (password_verify($password, $hash) ? "Success" : "Failed") . "\n\n";

// Test database connection and admin credentials
try {
    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->execute(['admin']);
    $admin = $stmt->fetch();

    echo "Database test:\n";
    if ($admin) {
        echo "Admin found in database\n";
        echo "Username: " . $admin['username'] . "\n";
        echo "Stored hash: " . $admin['password'] . "\n";
        echo "Password verification: " . (password_verify($password, $admin['password']) ? "Success" : "Failed") . "\n";
    } else {
        echo "Admin not found in database\n";
    }
} catch(PDOException $e) {
    echo "Database error: " . $e->getMessage() . "\n";
}
?> 