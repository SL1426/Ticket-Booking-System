<?php
require_once '../config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $movie_id = (int)$_POST['movie_id'];
    $theater_id = (int)$_POST['theater_id'];
    $show_date = $_POST['show_date'];
    $show_time = $_POST['show_time'];
    $price = (float)$_POST['price'];

    if ($movie_id <= 0) $errors[] = "Please select a movie";
    if ($theater_id <= 0) $errors[] = "Please select a theater";
    if (empty($show_date)) $errors[] = "Show date is required";
    if (empty($show_time)) $errors[] = "Show time is required";
    if ($price <= 0) $errors[] = "Price must be positive";

    if (empty($errors)) {
        try {
            // Get theater capacity
            $stmt = $pdo->prepare("SELECT total_seats FROM theaters WHERE theater_id = ?");
            $stmt->execute([$theater_id]);
            $theater = $stmt->fetch();
            $available_seats = $theater['total_seats'];

            $stmt = $pdo->prepare("
                INSERT INTO shows (movie_id, theater_id, show_date, show_time, price, available_seats)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$movie_id, $theater_id, $show_date, $show_time, $price, $available_seats]);
            $success = true;
        } catch(PDOException $e) {
            $errors[] = "Failed to add show: " . $e->getMessage();
        }
    }
}

// Fetch all shows with movie and theater details
$stmt = $pdo->query("
    SELECT s.*, m.title as movie_title, t.name as theater_name
    FROM shows s
    JOIN movies m ON s.movie_id = m.movie_id
    JOIN theaters t ON s.theater_id = t.theater_id
    ORDER BY s.show_date DESC, s.show_time
");
$shows = $stmt->fetchAll();

// Fetch movies and theaters for dropdowns
$movies = $pdo->query("SELECT * FROM movies ORDER BY title")->fetchAll();
$theaters = $pdo->query("SELECT * FROM theaters ORDER BY name")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Shows - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Manage Shows</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                Show added successfully!
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Add New Show</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="movie_id" class="form-label">Movie</label>
                                <select class="form-select" id="movie_id" name="movie_id" required>
                                    <option value="">Select a movie</option>
                                    <?php foreach ($movies as $movie): ?>
                                        <option value="<?php echo $movie['movie_id']; ?>">
                                            <?php echo htmlspecialchars($movie['title']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="theater_id" class="form-label">Theater</label>
                                <select class="form-select" id="theater_id" name="theater_id" required>
                                    <option value="">Select a theater</option>
                                    <?php foreach ($theaters as $theater): ?>
                                        <option value="<?php echo $theater['theater_id']; ?>">
                                            <?php echo htmlspecialchars($theater['name']); ?> - <?php echo htmlspecialchars($theater['location']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="show_date" class="form-label">Show Date</label>
                                <input type="date" class="form-control" id="show_date" name="show_date" required>
                            </div>
                            <div class="mb-3">
                                <label for="show_time" class="form-label">Show Time</label>
                                <input type="time" class="form-control" id="show_time" name="show_time" required>
                            </div>
                            <div class="mb-3">
                                <label for="price" class="form-label">Price</label>
                                <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Show</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5>Show List</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Movie</th>
                                        <th>Theater</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Price</th>
                                        <th>Available Seats</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($shows as $show): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($show['movie_title']); ?></td>
                                            <td><?php echo htmlspecialchars($show['theater_name']); ?></td>
                                            <td><?php echo date('Y-m-d', strtotime($show['show_date'])); ?></td>
                                            <td><?php echo date('H:i', strtotime($show['show_time'])); ?></td>
                                            <td>$<?php echo number_format($show['price'], 2); ?></td>
                                            <td><?php echo $show['available_seats']; ?></td>
                                            <td>
                                                <a href="edit_show.php?id=<?php echo $show['show_id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                                <a href="delete_show.php?id=<?php echo $show['show_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 