<?php
require_once '../config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$errors = [];
$success = false;
$movie = null;

// Get movie ID from URL
if (!isset($_GET['id'])) {
    header("Location: movies.php");
    exit();
}

$movie_id = (int)$_GET['id'];

// Fetch existing movie data
try {
    $stmt = $pdo->prepare("SELECT * FROM movies WHERE movie_id = ?");
    $stmt->execute([$movie_id]);
    $movie = $stmt->fetch();

    if (!$movie) {
        header("Location: movies.php");
        exit();
    }
} catch(PDOException $e) {
    $errors[] = "Failed to fetch movie: " . $e->getMessage();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $release_date = $_POST['release_date'];
    $duration = (int)$_POST['duration'];
    $trailer_url = trim($_POST['trailer_url']);
    $status = $_POST['status'];
    $current_poster = $movie['poster_url'];

    // Handle file upload if new poster is provided
    if (isset($_FILES['poster_image']) && $_FILES['poster_image']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['poster_image']['tmp_name'];
        $file_name = $_FILES['poster_image']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Generate unique filename
        $unique_filename = uniqid() . '.' . $file_ext;
        $upload_path = '../uploads/' . $unique_filename;
        
        // Check if file is an image
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($file_ext, $allowed_types)) {
            $errors[] = "Only JPG, JPEG, PNG & GIF files are allowed.";
        } else {
            if (move_uploaded_file($file_tmp, $upload_path)) {
                // Delete old poster if exists
                if ($current_poster && file_exists('../' . $current_poster)) {
                    unlink('../' . $current_poster);
                }
                $current_poster = 'uploads/' . $unique_filename;
            } else {
                $errors[] = "Failed to upload image.";
            }
        }
    }

    if (empty($title)) $errors[] = "Title is required";
    if (empty($description)) $errors[] = "Description is required";
    if (empty($release_date)) $errors[] = "Release date is required";
    if ($duration <= 0) $errors[] = "Duration must be positive";
    if (empty($trailer_url)) $errors[] = "Trailer URL is required";

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                UPDATE movies 
                SET title = ?, description = ?, release_date = ?, 
                    duration = ?, trailer_url = ?, poster_url = ?, status = ?
                WHERE movie_id = ?
            ");
            $stmt->execute([
                $title, $description, $release_date, 
                $duration, $trailer_url, $current_poster, $status, $movie_id
            ]);
            $success = true;
            
            // Refresh movie data
            $stmt = $pdo->prepare("SELECT * FROM movies WHERE movie_id = ?");
            $stmt->execute([$movie_id]);
            $movie = $stmt->fetch();
        } catch(PDOException $e) {
            $errors[] = "Failed to update movie: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Movie - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        <h5>Edit Movie</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo $error; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                Movie updated successfully!
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <input type="text" class="form-control" id="title" name="title" 
                                       value="<?php echo htmlspecialchars($movie['title']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" 
                                          rows="3" required><?php echo htmlspecialchars($movie['description']); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="release_date" class="form-label">Release Date</label>
                                <input type="date" class="form-control" id="release_date" name="release_date" 
                                       value="<?php echo date('Y-m-d', strtotime($movie['release_date'])); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="duration" class="form-label">Duration (minutes)</label>
                                <input type="number" class="form-control" id="duration" name="duration" 
                                       value="<?php echo $movie['duration']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="trailer_url" class="form-label">Trailer URL</label>
                                <input type="url" class="form-control" id="trailer_url" name="trailer_url" 
                                       value="<?php echo htmlspecialchars($movie['trailer_url']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="poster_image" class="form-label">Poster Image</label>
                                <input type="file" class="form-control" id="poster_image" name="poster_image" accept="image/*">
                                <small class="text-muted">Leave empty to keep current poster. Accepted formats: JPG, JPEG, PNG, GIF</small>
                                <?php if ($movie['poster_url']): ?>
                                    <div class="mt-2">
                                        <label>Current Poster:</label><br>
                                        <img src="<?php echo '../' . $movie['poster_url']; ?>" 
                                             alt="Current Poster" style="max-width: 200px;" class="mt-2">
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="upcoming" <?php echo $movie['status'] == 'upcoming' ? 'selected' : ''; ?>>Upcoming</option>
                                    <option value="now_showing" <?php echo $movie['status'] == 'now_showing' ? 'selected' : ''; ?>>Now Showing</option>
                                    <option value="ended" <?php echo $movie['status'] == 'ended' ? 'selected' : ''; ?>>Ended</option>
                                </select>
                            </div>
                            <div class="d-flex justify-content-between">
                                <a href="movies.php" class="btn btn-secondary">Back to Movies</a>
                                <button type="submit" class="btn btn-primary">Update Movie</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 