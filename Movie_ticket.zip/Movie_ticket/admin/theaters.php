<?php
require_once '../config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);
    $total_seats = (int)$_POST['total_seats'];

    if (empty($name)) $errors[] = "Theater name is required";
    if (empty($location)) $errors[] = "Location is required";
    if ($total_seats <= 0) $errors[] = "Total seats must be positive";

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO theaters (name, location, total_seats)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$name, $location, $total_seats]);
            $success = true;
        } catch(PDOException $e) {
            $errors[] = "Failed to add theater: " . $e->getMessage();
        }
    }
}

// Fetch all theaters
$stmt = $pdo->query("SELECT * FROM theaters ORDER BY name");
$theaters = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Theaters - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Manage Theaters</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                Theater added successfully!
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Add New Theater</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="name" class="form-label">Theater Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="location" class="form-label">Location</label>
                                <input type="text" class="form-control" id="location" name="location" required>
                            </div>
                            <div class="mb-3">
                                <label for="total_seats" class="form-label">Total Seats</label>
                                <input type="number" class="form-control" id="total_seats" name="total_seats" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Theater</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5>Theater List</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Location</th>
                                        <th>Total Seats</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($theaters as $theater): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($theater['name']); ?></td>
                                            <td><?php echo htmlspecialchars($theater['location']); ?></td>
                                            <td><?php echo $theater['total_seats']; ?></td>
                                            <td>
                                                <a href="edit_theater.php?id=<?php echo $theater['theater_id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                                <a href="delete_theater.php?id=<?php echo $theater['theater_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 