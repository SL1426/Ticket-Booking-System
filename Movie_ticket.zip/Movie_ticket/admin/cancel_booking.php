<?php
require_once '../config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: bookings.php");
    exit();
}

$booking_id = (int)$_GET['id'];

try {
    $pdo->beginTransaction();

    // Get booking details
    $stmt = $pdo->prepare("
        SELECT b.*, s.show_id, s.available_seats
        FROM bookings b
        JOIN shows s ON b.show_id = s.show_id
        WHERE b.booking_id = ? AND b.status = 'confirmed'
    ");
    $stmt->execute([$booking_id]);
    $booking = $stmt->fetch();

    if (!$booking) {
        throw new Exception("Booking not found or already cancelled");
    }

    // Update booking status
    $stmt = $pdo->prepare("
        UPDATE bookings 
        SET status = 'cancelled' 
        WHERE booking_id = ?
    ");
    $stmt->execute([$booking_id]);

    // Update available seats
    $stmt = $pdo->prepare("
        UPDATE shows 
        SET available_seats = available_seats + ? 
        WHERE show_id = ?
    ");
    $stmt->execute([$booking['total_seats'], $booking['show_id']]);

    $pdo->commit();
    $_SESSION['success'] = "Booking cancelled successfully";
} catch(Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = $e->getMessage();
}

header("Location: bookings.php");
exit();
?> 