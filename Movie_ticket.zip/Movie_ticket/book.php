<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['movie_id'])) {
    header("Location: index.php");
    exit();
}

$movie_id = $_GET['movie_id'];

// Fetch movie details
$stmt = $pdo->prepare("SELECT * FROM movies WHERE movie_id = ?");
$stmt->execute([$movie_id]);
$movie = $stmt->fetch();

if (!$movie) {
    header("Location: index.php");
    exit();
}

// Process booking form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $show_id = $_POST['show_id'];
    $seats = (int)$_POST['seats'];
    
    // Validate seats
    if ($seats <= 0) {
        $error = "Please select at least one seat";
    } else {
        // Get show details and verify available seats
        $stmt = $pdo->prepare("SELECT * FROM shows WHERE show_id = ?");
        $stmt->execute([$show_id]);
        $show = $stmt->fetch();
        
        if ($show && $show['available_seats'] >= $seats) {
            // Calculate total amount
            $total_amount = $show['price'] * $seats;
            
            // Store booking data in session
            $_SESSION['booking_data'] = [
                'show_id' => $show_id,
                'seats' => $seats,
                'total_amount' => $total_amount
            ];
            
            // Redirect to payment page
            header("Location: payment.php");
            exit();
        } else {
            $error = "Not enough seats available";
        }
    }
}

// Fetch theaters showing this movie
$stmt = $pdo->prepare("
    SELECT DISTINCT t.* FROM theaters t
    JOIN shows s ON t.theater_id = s.theater_id
    WHERE s.movie_id = ? AND s.show_date >= CURDATE()
    ORDER BY t.name
");
$stmt->execute([$movie_id]);
$theaters = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Tickets - <?php echo htmlspecialchars($movie['title']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #f84464;
            --secondary-color: #1f2533;
        }

        body {
            background-color: #f5f5f5;
        }

        .booking-container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .movie-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .movie-poster {
            height: 400px;
            object-fit: cover;
        }

        .movie-info {
            padding: 20px;
        }

        .booking-form {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 20px;
        }

        .form-select, .form-control {
            border: 1px solid #ddd;
            padding: 10px;
        }

        .book-btn {
            background-color: var(--primary-color);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 5px;
            font-weight: bold;
            width: 100%;
        }

        .book-btn:hover {
            background-color: #e03a58;
        }

        .show-time-btn {
            background-color: white;
            border: 1px solid var(--primary-color);
            color: var(--primary-color);
            padding: 8px 16px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
        }

        .show-time-btn:hover, .show-time-btn.selected {
            background-color: var(--primary-color);
            color: white;
        }

        .price-tag {
            color: var(--primary-color);
            font-weight: bold;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: var(--secondary-color);">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-film me-2"></i>MovieTicket
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="booking-container">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-4">
                    <div class="movie-card">
                        <img src="<?php echo htmlspecialchars($movie['poster_url']); ?>" class="movie-poster w-100" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                        <div class="movie-info">
                            <h4><?php echo htmlspecialchars($movie['title']); ?></h4>
                            <p class="mb-1">
                                <i class="far fa-clock me-2"></i><?php echo $movie['duration']; ?> minutes
                            </p>
                            <p class="mb-0">
                                <i class="far fa-calendar me-2"></i>Release: <?php echo date('d M Y', strtotime($movie['release_date'])); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="booking-form">
                        <h4 class="mb-4">Book Your Tickets</h4>
                        <form method="POST" action="" id="booking-form">
                            <div class="mb-3">
                                <label for="theater" class="form-label">Select Theater</label>
                                <select class="form-select" id="theater" name="theater_id" required>
                                    <option value="">Choose a theater</option>
                                    <?php foreach ($theaters as $theater): ?>
                                        <option value="<?php echo $theater['theater_id']; ?>">
                                            <?php echo htmlspecialchars($theater['name']); ?> - <?php echo htmlspecialchars($theater['location']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Select Show Time</label>
                                <div id="show-times" class="d-flex flex-wrap">
                                    <!-- Show times will be loaded here -->
                                </div>
                                <input type="hidden" name="show_id" id="show_id" required>
                            </div>

                            <div class="mb-3">
                                <label for="seats" class="form-label">Number of Seats</label>
                                <input type="number" class="form-control" id="seats" name="seats" min="1" max="10" required>
                                <small class="text-muted">Maximum 10 seats per booking</small>
                            </div>

                            <div class="mb-3" id="price-info" style="display: none;">
                                <p class="mb-1">Price per ticket: <span class="price-tag" id="price-per-ticket">$0</span></p>
                                <p class="mb-0">Total amount: <span class="price-tag" id="total-amount">$0</span></p>
                            </div>

                            <button type="submit" class="book-btn" disabled>Continue to Payment</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('theater').addEventListener('change', function() {
            const theaterId = this.value;
            const showTimesDiv = document.getElementById('show-times');
            const submitBtn = document.querySelector('button[type="submit"]');
            showTimesDiv.innerHTML = '';
            submitBtn.disabled = true;
            document.getElementById('show_id').value = '';
            document.getElementById('price-info').style.display = 'none';

            if (theaterId) {
                fetch(`get_shows.php?movie_id=<?php echo $movie_id; ?>&theater_id=${theaterId}`)
                    .then(response => response.json())
                    .then(shows => {
                        shows.forEach(show => {
                            const btn = document.createElement('button');
                            btn.type = 'button';
                            btn.className = 'show-time-btn';
                            btn.textContent = `${show.show_time} - ₹${show.price}`;
                            btn.onclick = function() {
                                document.querySelectorAll('.show-time-btn').forEach(b => b.classList.remove('selected'));
                                this.classList.add('selected');
                                document.getElementById('show_id').value = show.show_id;
                                document.getElementById('price-per-ticket').textContent = `₹${show.price}`;
                                document.getElementById('price-info').style.display = 'block';
                                updateTotal(show.price);
                                submitBtn.disabled = false;
                            };
                            showTimesDiv.appendChild(btn);
                        });
                    });
            }
        });

        document.getElementById('seats').addEventListener('input', function() {
            const pricePerTicket = parseFloat(document.getElementById('price-per-ticket').textContent.replace('₹', ''));
            updateTotal(pricePerTicket);
        });

        function updateTotal(pricePerTicket) {
            const seats = parseInt(document.getElementById('seats').value) || 0;
            const total = (pricePerTicket * seats).toFixed(2);
            document.getElementById('total-amount').textContent = `₹${total}`;
        }
    </script>
</body>
</html> 