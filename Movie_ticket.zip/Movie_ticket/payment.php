<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$booking_data = $_SESSION['booking_data'] ?? null;
if (!$booking_data) {
    header("Location: index.php");
    exit();
}

// Fetch movie and show details
$stmt = $pdo->prepare("
    SELECT m.title, m.poster_url, s.show_date, s.show_time, t.name as theater_name
    FROM shows s
    JOIN movies m ON s.movie_id = m.movie_id
    JOIN theaters t ON s.theater_id = t.theater_id
    WHERE s.show_id = ?
");
$stmt->execute([$booking_data['show_id']]);
$show_details = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Movie Ticket Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #f84464;
            --secondary-color: #1f2533;
        }

        body {
            background-color: #f5f5f5;
        }

        .payment-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .booking-summary {
            background-color: var(--secondary-color);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .movie-poster {
            width: 100px;
            border-radius: 5px;
        }

        .payment-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 20px;
        }

        .card-input {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            font-size: 16px;
        }

        .submit-btn {
            background-color: var(--primary-color);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 5px;
            font-weight: bold;
            width: 100%;
        }

        .submit-btn:hover {
            background-color: #e03a58;
        }

        .card-icon {
            font-size: 24px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container mt-5 mb-5">
        <div class="payment-container">
            <h2 class="mb-4">Payment Details</h2>

            <?php if (isset($_SESSION['payment_errors'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    foreach ($_SESSION['payment_errors'] as $error) {
                        echo $error . "<br>";
                    }
                    unset($_SESSION['payment_errors']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="booking-summary mb-4">
                <div class="row align-items-center">
                    <div class="col-md-2">
                        <img src="<?php echo htmlspecialchars($show_details['poster_url']); ?>" class="movie-poster" alt="Movie Poster">
                    </div>
                    <div class="col-md-6">
                        <h4><?php echo htmlspecialchars($show_details['title']); ?></h4>
                        <p class="mb-1">
                            <i class="fas fa-theater-masks me-2"></i>
                            <?php echo htmlspecialchars($show_details['theater_name']); ?>
                        </p>
                        <p class="mb-1">
                            <i class="far fa-calendar me-2"></i>
                            <?php echo date('d M Y', strtotime($show_details['show_date'])); ?>
                        </p>
                        <p class="mb-0">
                            <i class="far fa-clock me-2"></i>
                            <?php echo date('h:i A', strtotime($show_details['show_time'])); ?>
                        </p>
                    </div>
                    <div class="col-md-4 text-end">
                        <p class="mb-1">Seats: <?php echo $booking_data['seats']; ?></p>
                        <h4>Total: ₹<?php echo number_format($booking_data['total_amount'], 2); ?></h4>
                    </div>
                </div>
            </div>

            <div class="payment-card">
                <form action="process_payment.php" method="POST" id="payment-form">
                    <div class="mb-3">
                        <label class="form-label">Card Number</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-credit-card card-icon"></i></span>
                            <input type="text" class="form-control card-input" name="card_number" id="card_number" placeholder="1234 5678 9012 3456" maxlength="19" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Expiry Date</label>
                            <input type="text" class="form-control card-input" name="card_expiry" id="card_expiry" placeholder="MM/YY" maxlength="5" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">CVV</label>
                            <input type="password" class="form-control card-input" name="card_cvv" id="card_cvv" placeholder="123" maxlength="3" required>
                        </div>
                    </div>
                    <button type="submit" name="payment_submit" class="submit-btn">Pay ₹<?php echo number_format($booking_data['total_amount'], 2); ?></button>
                </form>
            </div>

            <div class="mt-3 text-center text-muted">
                <small>This is a demo payment page. Use any valid-format card number for testing.</small><br>
                <small>Example: 4111 1111 1111 1111, Expiry: 12/25, CVV: 123</small>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Format card number with spaces
        document.getElementById('card_number').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
            let formattedValue = value.match(/.{1,4}/g)?.join(' ') ?? '';
            e.target.value = formattedValue;
        });

        // Format expiry date
        document.getElementById('card_expiry').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
            if (value.length >= 2) {
                value = value.slice(0, 2) + '/' + value.slice(2);
            }
            e.target.value = value;
        });

        // Validate CVV to only allow numbers
        document.getElementById('card_cvv').addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>
</html> 