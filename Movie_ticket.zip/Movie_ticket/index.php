<?php
require_once 'config.php';
session_start();

// Fetch movies that are currently showing and upcoming
$stmt = $pdo->prepare("SELECT * FROM movies WHERE status IN ('now_showing', 'upcoming') ORDER BY release_date DESC");
$stmt->execute();
$all_movies = $stmt->fetchAll();

// Separate movies by status
$now_showing = array_filter($all_movies, function($movie) {
    return $movie['status'] == 'now_showing';
});
$upcoming = array_filter($all_movies, function($movie) {
    return $movie['status'] == 'upcoming';
});

// Function to extract YouTube video ID from URL
function getYoutubeVideoId($url) {
    $video_id = '';
    if (preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $url, $match)) {
        $video_id = $match[1];
    }
    return $video_id;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Ticket Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #f84464;
            --secondary-color: #1f2533;
        }
        
        body {
            background-color: #f5f5f5;
        }
        
        .navbar {
            background-color: var(--secondary-color) !important;
        }
        
        .navbar-brand {
            color: var(--primary-color) !important;
            font-weight: bold;
            font-size: 1.5rem;
        }
        
        .nav-link {
            color: white !important;
        }
        
        .movie-card {
            transition: transform 0.3s;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            background: white;
        }
        
        .movie-card:hover {
            transform: translateY(-5px);
        }
        
        .movie-poster {
            height: 300px;
            object-fit: cover;
        }
        
        .movie-title {
            color: var(--secondary-color);
            font-weight: bold;
        }
        
        .movie-duration {
            color: #666;
            font-size: 0.9rem;
        }
        
        .book-btn {
            background-color: var(--primary-color);
            border: none;
            border-radius: 5px;
            padding: 8px 20px;
            color: white;
            font-weight: bold;
        }
        
        .book-btn:hover {
            background-color: #e03a58;
            color: white;
        }
        
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            height: 400px;
            display: flex;
            align-items: center;
            color: white;
        }
        
        .hero-content {
            max-width: 600px;
        }
        
        .hero-title {
            font-size: 3rem;
            font-weight: bold;
            margin-bottom: 1rem;
        }
        
        .hero-subtitle {
            font-size: 1.2rem;
            margin-bottom: 2rem;
        }
        
        .section-title {
            color: var(--secondary-color);
            font-weight: bold;
            margin: 2rem 0;
            position: relative;
        }
        
        .section-title:after {
            content: '';
            display: block;
            width: 50px;
            height: 3px;
            background-color: var(--primary-color);
            margin-top: 10px;
        }

        .status-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 0.8rem;
            font-weight: bold;
            z-index: 1;
        }

        .status-now-showing {
            background-color: var(--primary-color);
            color: white;
        }

        .status-upcoming {
            background-color: #ffc107;
            color: black;
        }

        .movie-card {
            position: relative;
        }

        .release-date {
            font-size: 0.85rem;
            color: #666;
        }

        .trailer-btn {
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            padding: 8px 20px;
            color: white;
            font-weight: bold;
            margin-right: 10px;
        }
        
        .trailer-btn:hover {
            background-color: #218838;
            color: white;
        }

        .modal-xl {
            max-width: 90%;
        }

        .trailer-modal .modal-content {
            background-color: #000;
        }

        .trailer-container {
            position: relative;
            padding-bottom: 56.25%; /* 16:9 aspect ratio */
            height: 0;
            overflow: hidden;
        }

        .trailer-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 0;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-film me-2"></i>MovieTicket
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="bookings.php">
                                <i class="fas fa-ticket-alt me-1"></i>My Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Logout
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">
                                <i class="fas fa-sign-in-alt me-1"></i>Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">
                                <i class="fas fa-user-plus me-1"></i>Register
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">Book Your Movie Tickets Online</h1>
                <p class="hero-subtitle">Experience the magic of cinema with the best seats in town</p>
                <a href="#movies" class="book-btn">Book Now</a>
            </div>
        </div>
    </div>

    <div class="container mt-5" id="movies">
        <?php if (!empty($now_showing)): ?>
            <h2 class="section-title">Now Showing</h2>
            <div class="row">
                <?php foreach ($now_showing as $movie): ?>
                    <div class="col-md-4 mb-4">
                        <div class="movie-card">
                            <span class="status-badge status-now-showing">Now Showing</span>
                            <img src="<?php echo htmlspecialchars($movie['poster_url']); ?>" class="movie-poster w-100" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                            <div class="p-3">
                                <h5 class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></h5>
                                <p class="movie-duration mb-1">
                                    <i class="far fa-clock me-1"></i><?php echo $movie['duration']; ?> min
                                </p>
                                <p class="release-date mb-2">
                                    <i class="far fa-calendar me-1"></i>Release: <?php echo date('d M Y', strtotime($movie['release_date'])); ?>
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <button type="button" class="trailer-btn" data-bs-toggle="modal" data-bs-target="#trailerModal<?php echo $movie['movie_id']; ?>">
                                        <i class="fas fa-play me-1"></i>Trailer
                                    </button>
                                    <a href="book.php?movie_id=<?php echo $movie['movie_id']; ?>" class="book-btn">Book Now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Trailer Modal -->
                    <div class="modal fade trailer-modal" id="trailerModal<?php echo $movie['movie_id']; ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-xl modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header border-0">
                                    <h5 class="modal-title text-white"><?php echo htmlspecialchars($movie['title']); ?> - Trailer</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body p-0">
                                    <div class="trailer-container">
                                        <iframe src="https://www.youtube.com/embed/<?php echo getYoutubeVideoId($movie['trailer_url']); ?>?autoplay=0" 
                                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                                allowfullscreen></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($upcoming)): ?>
            <h2 class="section-title mt-5">Coming Soon</h2>
            <div class="row">
                <?php foreach ($upcoming as $movie): ?>
                    <div class="col-md-4 mb-4">
                        <div class="movie-card">
                            <span class="status-badge status-upcoming">Coming Soon</span>
                            <img src="<?php echo htmlspecialchars($movie['poster_url']); ?>" class="movie-poster w-100" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                            <div class="p-3">
                                <h5 class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></h5>
                                <p class="movie-duration mb-1">
                                    <i class="far fa-clock me-1"></i><?php echo $movie['duration']; ?> min
                                </p>
                                <p class="release-date mb-2">
                                    <i class="far fa-calendar me-1"></i>Release: <?php echo date('d M Y', strtotime($movie['release_date'])); ?>
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <button type="button" class="trailer-btn" data-bs-toggle="modal" data-bs-target="#trailerModal<?php echo $movie['movie_id']; ?>">
                                        <i class="fas fa-play me-1"></i>Trailer
                                    </button>
                                    <span class="text-muted">Coming Soon</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Trailer Modal -->
                    <div class="modal fade trailer-modal" id="trailerModal<?php echo $movie['movie_id']; ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-xl modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header border-0">
                                    <h5 class="modal-title text-white"><?php echo htmlspecialchars($movie['title']); ?> - Trailer</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body p-0">
                                    <div class="trailer-container">
                                        <iframe src="https://www.youtube.com/embed/<?php echo getYoutubeVideoId($movie['trailer_url']); ?>?autoplay=0" 
                                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                                allowfullscreen></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (empty($now_showing) && empty($upcoming)): ?>
            <div class="alert alert-info">
                No movies available at the moment. Please check back later.
            </div>
        <?php endif; ?>
    </div>

    <footer class="bg-dark text-white mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>About Us</h5>
                    <p>Your one-stop destination for movie tickets. Book your favorite movies and enjoy the best cinema experience.</p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">Movies</a></li>
                        <li><a href="#" class="text-white">Theaters</a></li>
                        <li><a href="#" class="text-white">Offers</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contact Us</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-phone me-2"></i> +1 234 567 890</li>
                        <li><i class="fas fa-envelope me-2"></i> support@movieticket.com</li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Stop video when modal is closed
        document.querySelectorAll('.trailer-modal').forEach(modal => {
            modal.addEventListener('hidden.bs.modal', function () {
                const iframe = this.querySelector('iframe');
                const videoSrc = iframe.src;
                iframe.src = videoSrc;
            });
        });
    </script>
</body>
</html> 
</html> 