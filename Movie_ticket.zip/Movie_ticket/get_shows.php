<?php
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_GET['movie_id']) || !isset($_GET['theater_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing parameters']);
    exit();
}

$movie_id = $_GET['movie_id'];
$theater_id = $_GET['theater_id'];

try {
    $stmt = $pdo->prepare("
        SELECT s.*, m.title as movie_title, t.name as theater_name
        FROM shows s
        JOIN movies m ON s.movie_id = m.movie_id
        JOIN theaters t ON s.theater_id = t.theater_id
        WHERE s.movie_id = ? AND s.theater_id = ? AND s.show_date >= CURDATE()
        ORDER BY s.show_date, s.show_time
    ");
    $stmt->execute([$movie_id, $theater_id]);
    $shows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($shows);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?> 