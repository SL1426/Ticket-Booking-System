<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id']) || !isset($_POST['payment_submit'])) {
    header("Location: index.php");
    exit();
}

$booking_data = $_SESSION['booking_data'] ?? null;
if (!$booking_data) {
    header("Location: index.php");
    exit();
}

// Simulate payment processing
$card_number = preg_replace('/\s+/', '', $_POST['card_number']);
$card_expiry = $_POST['card_expiry'];
$card_cvv = $_POST['card_cvv'];

// Simple validation
$errors = [];
if (strlen($card_number) != 16) {
    $errors[] = "Invalid card number";
}
if (!preg_match('/^(0[1-9]|1[0-2])\/([0-9]{2})$/', $card_expiry)) {
    $errors[] = "Invalid expiry date";
}
if (strlen($card_cvv) != 3) {
    $errors[] = "Invalid CVV";
}

if (empty($errors)) {
    try {
        $pdo->beginTransaction();

        // Create booking record
        $stmt = $pdo->prepare("
            INSERT INTO bookings (user_id, show_id, total_seats, total_amount, status)
            VALUES (?, ?, ?, ?, 'confirmed')
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            $booking_data['show_id'],
            $booking_data['seats'],
            $booking_data['total_amount']
        ]);
        $booking_id = $pdo->lastInsertId();

        // Update available seats
        $stmt = $pdo->prepare("
            UPDATE shows 
            SET available_seats = available_seats - ?
            WHERE show_id = ?
        ");
        $stmt->execute([$booking_data['seats'], $booking_data['show_id']]);

        $pdo->commit();
        
        // Clear booking data from session
        unset($_SESSION['booking_data']);
        
        // Redirect to success page
        $_SESSION['payment_success'] = true;
        $_SESSION['booking_id'] = $booking_id;
        header("Location: booking_confirmation.php");
        exit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $errors[] = "Booking failed: " . $e->getMessage();
    }
}

if (!empty($errors)) {
    $_SESSION['payment_errors'] = $errors;
    header("Location: payment.php");
    exit();
}
?> 